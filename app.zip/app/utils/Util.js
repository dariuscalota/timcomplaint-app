//we can use this file mainly to store global data across the application
//data stored in this variables is erased after the app is closed
global.user = {};